<?php
 // Membuat data session
 session_start();
 echo "Selamat datang di halaman session <br/>
 ID session Anda adalah : " . session_id();
 ?> 